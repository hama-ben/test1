/**
 * useRealtimeOrders
 *
 * Subscribes to the Supabase Realtime broadcast channel "orders:new".
 * When the server fires a `new_order` event:
 *   1. Invalidates the active-orders React Query cache for this driver
 *      (the server re-fetches and filters by commune server-side).
 *   2. Once the query resolves with a higher count than before, sets
 *      `notification = true` so the UI can show an alert.
 *
 * Zero false positives: the notification only fires when the refetch
 * actually returns more orders for THIS driver's commune.
 */

import { useEffect, useRef, useState, useCallback } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/lib/supabase";
import { getGetActiveOrdersQueryKey } from "@workspace/api-client-react";

export function useRealtimeOrders(driverId: string, currentOrderCount: number) {
  const queryClient = useQueryClient();
  const [notification, setNotification] = useState(false);

  const prevCountRef = useRef(-1);
  const pendingBroadcastRef = useRef(false);

  // Detect a commune-matched new order: count must increase AND a broadcast must
  // have arrived since the last refetch. This prevents false positives.
  useEffect(() => {
    if (prevCountRef.current === -1) {
      // First render — initialise baseline count without showing a notification.
      prevCountRef.current = currentOrderCount;
      return;
    }

    if (pendingBroadcastRef.current && currentOrderCount > prevCountRef.current) {
      setNotification(true);
      pendingBroadcastRef.current = false;
    }

    prevCountRef.current = currentOrderCount;
  }, [currentOrderCount]);

  // Subscribe to the Realtime broadcast channel.
  useEffect(() => {
    const channel = supabase
      .channel("orders:new")
      .on("broadcast", { event: "new_order" }, () => {
        // Mark that a broadcast arrived so the count-watcher above knows
        // a subsequent count increase is due to a real new order.
        pendingBroadcastRef.current = true;

        // Trigger an immediate background refetch (commune-filtered server-side).
        queryClient.invalidateQueries({
          queryKey: getGetActiveOrdersQueryKey({ driverId }),
        });
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [driverId, queryClient]);

  const dismiss = useCallback(() => setNotification(false), []);

  return { notification, dismiss };
}
