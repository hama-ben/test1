# Talabati طلباتي

Water delivery app for Algeria. Customers order drinking water; drivers accept and fulfill deliveries.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 8080)
- `pnpm --filter @workspace/talabati run dev` — run the frontend (port 19283, preview at `/`)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` (Replit managed), `SUPABASE_URL`, `SUPABASE_ANON_KEY`

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Frontend: React + Vite + Tailwind CSS v4 + shadcn/ui (RTL Arabic)
- API: Express 5 (port 8080, path `/api`)
- DB: Replit PostgreSQL + Drizzle ORM
- Auth / Storage: Supabase (OTP email verification + public storage bucket)
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `lib/db/src/schema/index.ts` — DB schema (users, orders, driver_status, driver_details, subscription_payments)
- `lib/api-spec/openapi.yaml` — OpenAPI spec (source of truth for all contracts)
- `lib/api-zod/src/generated/` — generated Zod schemas (from codegen)
- `lib/api-client-react/src/generated/` — generated React Query hooks (from codegen)
- `artifacts/api-server/src/routes/` — Express route handlers (auth, driver, orders, health)
- `artifacts/talabati/src/` — React frontend
- `artifacts/talabati/src/lib/supabase.ts` — Supabase client + file upload helper

## Architecture decisions

- **Replit Postgres for app data, Supabase for auth + storage.** Drizzle ORM handles all business data; Supabase provides OTP email verification and the `driver-verification` public storage bucket.
- **Drivers are auto-approved on registration** (`accountStatus = 'active'`). They go straight to the docs upload flow, bypassing the "account under review" overlay entirely.
- **Two-step registration flow:** `POST /api/auth/register-request` sends Supabase OTP → `POST /api/auth/verify-otp` verifies and creates the DB user.
- **PostgreSQL error 42P01 (relation does not exist) is caught and surfaced** as a 503 with a human-readable Arabic message instead of crashing the server.
- **Supabase storage uploads use the anon key only** — RLS is disabled on the `driver-verification` bucket, so no service-role key or extra Authorization headers are needed.

## Product

- **Customers:** register, log in, place water orders with optional GPS location, track order status in real time.
- **Drivers:** register (auto-approved), upload truck photo + license, toggle availability (حاضر / استراحة / مغلق), accept orders atomically (collision-safe), update delivery status.
- **Admin:** view/update driver account status and subscription expiry; review subscription payment receipts.

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- After any change to `lib/api-spec/openapi.yaml`, re-run codegen before using the updated hooks.
- `pnpm run typecheck:libs` must run before `pnpm --filter @workspace/api-server run typecheck` or you'll get stale declaration errors.
- The `driver-verification` Supabase storage bucket must exist and have RLS disabled; create it once in the Supabase dashboard.
- `SUPABASE_URL` must be the full project URL (`https://xxxx.supabase.co`), not an internal/local URL.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
