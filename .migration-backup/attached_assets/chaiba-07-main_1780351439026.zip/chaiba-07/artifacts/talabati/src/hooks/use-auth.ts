import { create } from "zustand";

interface AuthState {
  userId: string | null;
  name: string | null;
  email: string | null;
  userType: string | null;
  setAuth: (data: { userId: string; name: string; email: string; userType: string }) => void;
  logout: () => void;
}

export const useAuth = create<AuthState>((set) => {
  const storedUserId = localStorage.getItem("userId");
  const storedName = localStorage.getItem("name");
  const storedEmail = localStorage.getItem("email");
  const storedUserType = localStorage.getItem("userType");

  return {
    userId: storedUserId,
    name: storedName,
    email: storedEmail,
    userType: storedUserType,
    setAuth: (data) => {
      localStorage.setItem("userId", data.userId);
      localStorage.setItem("name", data.name);
      localStorage.setItem("email", data.email);
      localStorage.setItem("userType", data.userType);
      set(data);
    },
    logout: () => {
      localStorage.removeItem("userId");
      localStorage.removeItem("name");
      localStorage.removeItem("email");
      localStorage.removeItem("userType");
      set({ userId: null, name: null, email: null, userType: null });
    },
  };
});
