import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useLogin } from "@workspace/api-client-react";
import { Droplets, Mail, Lock, Loader2, ArrowRight } from "lucide-react";
import { Link } from "wouter";

export default function Login() {
  const [, setLocation] = useLocation();
  const { userId, userType, setAuth } = useAuth();
  
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const loginMutation = useLogin();

  useEffect(() => {
    if (userId) {
      if (userType === "سائق") {
        setLocation("/driver-dashboard");
      } else {
        setLocation("/dashboard");
      }
    }
  }, [userId, userType, setLocation]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    
    if (!email || !password) {
      setError("يرجى إدخال البريد الإلكتروني وكلمة المرور");
      return;
    }

    loginMutation.mutate({ data: { email, password } }, {
      onSuccess: (data) => {
        setAuth({
          userId: data.userId,
          name: data.name,
          email: data.email,
          userType: data.userType,
        });
        if (data.userType === "سائق") {
          setLocation("/driver-dashboard");
        } else {
          setLocation("/dashboard");
        }
      },
      onError: (err: any) => {
        setError(err?.response?.data?.error || "حدث خطأ أثناء تسجيل الدخول");
      }
    });
  };

  return (
    <div className="min-h-[100dvh] flex flex-col items-center justify-center p-6 relative overflow-hidden bg-gradient-to-b from-blue-50 to-white dark:from-slate-900 dark:to-slate-950">
      {/* Decorative background elements */}
      <div className="absolute top-[-10%] left-[-10%] w-96 h-96 bg-blue-400/20 rounded-full mix-blend-multiply filter blur-3xl opacity-70 animate-blob"></div>
      <div className="absolute top-[-10%] right-[-10%] w-96 h-96 bg-cyan-400/20 rounded-full mix-blend-multiply filter blur-3xl opacity-70 animate-blob animation-delay-2000"></div>
      <div className="absolute bottom-[-20%] left-[20%] w-96 h-96 bg-sky-400/20 rounded-full mix-blend-multiply filter blur-3xl opacity-70 animate-blob animation-delay-4000"></div>

      <div className="w-full max-w-sm relative z-10">
        <div className="flex flex-col items-center mb-8">
          <div className="w-20 h-20 bg-gradient-to-tr from-primary to-cyan-400 rounded-3xl flex items-center justify-center shadow-lg shadow-primary/30 mb-6 rotate-3">
            <Droplets className="w-10 h-10 text-white -rotate-3" />
          </div>
          <h1 className="text-3xl font-bold text-slate-800 dark:text-white mb-2">طلباتي</h1>
          <p className="text-slate-500 dark:text-slate-400 text-center">أسرع وأسهل طريقة لطلب مياه الشرب</p>
        </div>

        <form onSubmit={handleSubmit} className="glass-panel rounded-3xl p-6 mb-6">
          {error && (
            <div className="bg-destructive/10 text-destructive text-sm p-3 rounded-2xl mb-4 text-center">
              {error}
            </div>
          )}

          <div className="space-y-4">
            <div className="relative">
              <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none text-slate-400">
                <Mail className="h-5 w-5" />
              </div>
              <input
                type="email"
                placeholder="البريد الإلكتروني"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-white/50 dark:bg-black/50 border border-slate-200 dark:border-slate-800 rounded-2xl py-3 pr-10 pl-4 focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all"
                dir="rtl"
                data-testid="input-email"
              />
            </div>
            
            <div className="relative">
              <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none text-slate-400">
                <Lock className="h-5 w-5" />
              </div>
              <input
                type="password"
                placeholder="كلمة المرور"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-white/50 dark:bg-black/50 border border-slate-200 dark:border-slate-800 rounded-2xl py-3 pr-10 pl-4 focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all"
                dir="rtl"
                data-testid="input-password"
              />
            </div>

            <button
              type="submit"
              disabled={loginMutation.isPending}
              className="w-full bg-primary hover:bg-primary/90 text-white font-medium py-3.5 rounded-2xl flex items-center justify-center gap-2 transition-all shadow-md shadow-primary/20 active:scale-[0.98]"
              data-testid="button-submit-login"
            >
              {loginMutation.isPending ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <>
                  <span>تسجيل الدخول</span>
                  <ArrowRight className="w-4 h-4 rotate-180" />
                </>
              )}
            </button>
          </div>
        </form>

        <div className="text-center">
          <p className="text-slate-600 dark:text-slate-400">
            ليس لديك حساب؟{" "}
            <Link href="/register" className="text-primary font-bold hover:underline" data-testid="link-register">
              سجل الآن
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
