import { useState, useEffect, useRef, useCallback } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Layout } from "@/components/layout";
import { useCreateOrder, useGetUserOrders, getGetUserOrdersQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import {
  Droplet, Package, ShoppingBag, ListOrdered, CheckCircle2,
  Truck, Clock, ArrowRight, Loader2, MessageCircle, MapPin, Bell, X
} from "lucide-react";
import { format } from "date-fns";

type View = "menu" | "new-order" | "my-orders";

const VOLUMES = ["5ل", "10ل", "15ل", "20ل", "50ل", "100ل", "150ل", "200ل", "500ل", "1000ل"];
const BARRELS = [1, 2, 3, 5];

// ─────────────────────────────────────────────────────────────────────────────
// [تعديل 4]: نظام الإشعار الصوتي المتكرر (Loop) لوصول السائق
// يعمل بتكرار لانهائي ولا يتوقف إلا عند ضغط المستهلك على "حسناً، في الطريق"
// ─────────────────────────────────────────────────────────────────────────────

function createSingleBeep() {
  try {
    const ctx = new AudioContext();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.type = "sine";
    osc.frequency.setValueAtTime(880, ctx.currentTime);
    osc.frequency.setValueAtTime(660, ctx.currentTime + 0.15);
    osc.frequency.setValueAtTime(880, ctx.currentTime + 0.3);
    gain.gain.setValueAtTime(0.5, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.65);
    osc.start(ctx.currentTime);
    osc.stop(ctx.currentTime + 0.7);
    // Close context after beep finishes to release resources
    setTimeout(() => { try { ctx.close(); } catch { /* ignore */ } }, 900);
  } catch {
    // AudioContext unavailable — fail silently
  }
}

export default function Dashboard() {
  const { userId, userType } = useAuth();
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const [view, setView] = useState<View>("menu");
  const [showArrivalModal, setShowArrivalModal] = useState(false);
  const arrivedOrderIdRef = useRef<string | null>(null);

  // Ref holding the arrival sound loop interval — cleared only on user acknowledge
  const arrivalLoopRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const [supportOpen, setSupportOpen] = useState(false);
  const [chatMessages, setChatMessages] = useState<{ from: "user" | "bot"; text: string }[]>([
    { from: "bot", text: "مرحباً! كيف يمكنني مساعدتك في طلب المياه؟" }
  ]);
  const [chatInput, setChatInput] = useState("");

  // Auth Guard
  if (!userId) { setLocation("/"); return null; }
  if (userType === "سائق") { setLocation("/driver-dashboard"); return null; }

  // Start looping arrival sound — loops every 1.5 seconds until explicitly stopped
  const startArrivalLoop = () => {
    stopArrivalLoop();
    createSingleBeep();
    arrivalLoopRef.current = setInterval(() => {
      createSingleBeep();
    }, 1500);
  };

  // Stop the loop — called ONLY when the user taps "حسناً، في الطريق"
  const stopArrivalLoop = () => {
    if (arrivalLoopRef.current !== null) {
      clearInterval(arrivalLoopRef.current);
      arrivalLoopRef.current = null;
    }
  };

  const handleAcknowledge = () => {
    stopArrivalLoop();         // stop sound
    setShowArrivalModal(false); // close modal
  };

  const handleSendChat = () => {
    const msg = chatInput.trim();
    if (!msg) return;
    setChatMessages(prev => [...prev, { from: "user", text: msg }]);
    setChatInput("");
    setTimeout(() => {
      const botReply = getBotReply(msg);
      setChatMessages(prev => [...prev, { from: "bot", text: botReply }]);
    }, 600);
  };

  return (
    <Layout>
      {/* Arrival Modal — صوت متكرر لا يتوقف إلا بضغط المستخدم */}
      {showArrivalModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-sm">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-8 mx-4 max-w-sm w-full shadow-2xl border border-sky-200 dark:border-sky-800 text-center animate-in zoom-in-95 duration-300">
            <div className="w-20 h-20 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-5 animate-bounce">
              <Truck className="w-10 h-10 text-amber-500" />
            </div>
            <h2 className="text-2xl font-black text-slate-800 dark:text-white mb-3">
              شاحنة الماء وصلت!
            </h2>
            <p className="text-slate-600 dark:text-slate-300 leading-relaxed mb-6">
              السائق متواجد الآن أمام منزلك، يرجى الخروج لاستلام الطلب.
            </p>
            {/* الضغط على هذا الزر هو الطريقة الوحيدة لإيقاف الصوت */}
            <button
              onClick={handleAcknowledge}
              className="w-full bg-gradient-to-r from-amber-400 to-orange-500 text-white font-bold py-3.5 rounded-2xl shadow-lg shadow-amber-400/30 hover:opacity-90 transition-all active:scale-[0.98]"
              data-testid="button-close-arrival-modal"
            >
              حسناً، في الطريق
            </button>
          </div>
        </div>
      )}

      {view === "menu" && <MenuView onSelect={setView} />}
      {view === "new-order" && (
        <NewOrderView
          onBack={() => setView("menu")}
          onSuccess={() => setView("my-orders")}
          userId={userId}
          queryClient={queryClient}
        />
      )}
      {view === "my-orders" && (
        <MyOrdersView
          onBack={() => setView("menu")}
          userId={userId}
          onDriverArrived={(orderId) => {
            if (arrivedOrderIdRef.current !== orderId) {
              arrivedOrderIdRef.current = orderId;
              setShowArrivalModal(true);
              startArrivalLoop(); // تشغيل الصوت بتكرار لانهائي
            }
          }}
        />
      )}

      {/* Support Chat FAB */}
      <button
        onClick={() => setSupportOpen(v => !v)}
        className="fixed bottom-6 left-6 w-14 h-14 bg-primary text-white rounded-full flex items-center justify-center shadow-xl shadow-primary/30 hover:scale-105 active:scale-95 transition-all z-50"
        data-testid="button-support"
        title="تواصل مع الدعم"
      >
        {supportOpen ? <X className="w-6 h-6" /> : <MessageCircle className="w-6 h-6" />}
      </button>

      {supportOpen && (
        <div className="fixed bottom-24 left-6 w-80 glass-panel rounded-3xl shadow-2xl z-50 overflow-hidden flex flex-col" style={{ maxHeight: "420px" }}>
          <div className="bg-gradient-to-r from-primary to-cyan-500 text-white p-4 font-bold text-center">خدمة العملاء</div>
          <div className="flex-1 overflow-y-auto p-4 space-y-2" style={{ minHeight: "200px", maxHeight: "280px" }}>
            {chatMessages.map((m, i) => (
              <div key={i} className={`flex ${m.from === "user" ? "justify-start" : "justify-end"}`}>
                <div className={`max-w-[75%] px-3 py-2 rounded-2xl text-sm ${m.from === "user" ? "bg-primary text-white" : "bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200"}`}>
                  {m.text}
                </div>
              </div>
            ))}
          </div>
          <div className="p-3 border-t border-slate-200 dark:border-slate-700 flex gap-2">
            <input value={chatInput} onChange={e => setChatInput(e.target.value)}
              onKeyDown={e => e.key === "Enter" && handleSendChat()}
              placeholder="اكتب سؤالك..." className="flex-1 bg-slate-100 dark:bg-slate-800 rounded-xl px-3 py-2 text-sm outline-none"
              data-testid="input-chat" />
            <button onClick={handleSendChat} className="bg-primary text-white rounded-xl px-3 py-2 text-sm font-bold" data-testid="button-chat-send">إرسال</button>
          </div>
        </div>
      )}
    </Layout>
  );
}

function getBotReply(msg: string): string {
  const q = msg.toLowerCase();
  if (q.includes("سعر") || q.includes("تكلف")) return "الأسعار تبدأ من 25 دج للتر وتعتمد على الحجم والكمية. 💧";
  if (q.includes("وقت") || q.includes("كم") || q.includes("متى")) return "يصل الطلب في غضون 30 إلى 60 دقيقة حسب موقعك. 🚚";
  if (q.includes("الغ") || q.includes("إلغ")) return "يمكنك إلغاء الطلب فقط إذا كان في حالة 'معلق'. تواصل مع الدعم مباشرة.";
  if (q.includes("دفع") || q.includes("كيف")) return "الدفع يكون نقداً عند الاستلام. 💵";
  return "شكراً لتواصلك! فريق الدعم سيرد عليك قريباً على رقم هاتفك المسجل. 😊";
}

function MenuView({ onSelect }: { onSelect: (view: View) => void }) {
  return (
    <div className="flex flex-col gap-6 mt-8">
      <button onClick={() => onSelect("new-order")} className="bubble-card p-8 flex flex-col items-center justify-center gap-4 group" data-testid="button-nav-new-order">
        <div className="w-20 h-20 bg-gradient-to-tr from-sky-400 to-primary rounded-full flex items-center justify-center shadow-lg shadow-sky-400/40 group-hover:scale-110 transition-transform duration-300">
          <ShoppingBag className="w-10 h-10 text-white" />
        </div>
        <h2 className="text-2xl font-bold text-slate-800 dark:text-white">طلب جديد</h2>
        <p className="text-slate-500 text-center max-w-[200px]">اطلب مياه شرب نقية وتصلك في أسرع وقت</p>
      </button>
      <button onClick={() => onSelect("my-orders")} className="bubble-card p-8 flex flex-col items-center justify-center gap-4 group" data-testid="button-nav-my-orders">
        <div className="w-20 h-20 bg-gradient-to-tr from-teal-400 to-emerald-500 rounded-full flex items-center justify-center shadow-lg shadow-teal-400/40 group-hover:scale-110 transition-transform duration-300">
          <ListOrdered className="w-10 h-10 text-white" />
        </div>
        <h2 className="text-2xl font-bold text-slate-800 dark:text-white">طلباتي</h2>
        <p className="text-slate-500 text-center max-w-[200px]">تتبع طلباتك السابقة والحالية</p>
      </button>
    </div>
  );
}

function NewOrderView({
  onBack, onSuccess, userId, queryClient,
}: {
  onBack: () => void; onSuccess: () => void;
  userId: string; queryClient: ReturnType<typeof useQueryClient>;
}) {
  const [selectedVolumes, setSelectedVolumes] = useState<string[]>([]);
  const [barrelCount, setBarrelCount] = useState<number>(1);
  const [error, setError] = useState("");
  const [gpsState, setGpsState] = useState<"idle" | "loading" | "acquired">("idle");
  const [coords, setCoords] = useState<{ lat: number; lng: number } | null>(null);
  const createOrderMutation = useCreateOrder();

  const toggleVolume = (vol: string) => {
    if (selectedVolumes.includes(vol)) {
      setSelectedVolumes(prev => prev.filter(v => v !== vol));
    } else {
      if (selectedVolumes.length >= 3) return;
      setSelectedVolumes(prev => [...prev, vol]);
    }
  };

  const calculatePrice = () => {
    if (selectedVolumes.length === 0) return 0;
    const totalLiters = selectedVolumes.reduce((acc, vol) => {
      const num = parseInt(vol.replace("ل", ""), 10);
      return acc + (isNaN(num) ? 0 : num);
    }, 0);
    return barrelCount * (totalLiters * 5);
  };

  const totalPrice = calculatePrice();

  const handleLocate = () => {
    if (!navigator.geolocation) { setError("المتصفح لا يدعم تحديد الموقع الجغرافي"); return; }
    setGpsState("loading");
    navigator.geolocation.getCurrentPosition(
      (pos) => { setCoords({ lat: pos.coords.latitude, lng: pos.coords.longitude }); setGpsState("acquired"); setError(""); },
      () => { setGpsState("idle"); setError("تعذّر تحديد موقعك. تأكد من منح الإذن للمتصفح."); },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  const handleSubmit = () => {
    if (selectedVolumes.length === 0) { setError("الرجاء اختيار حجم واحد على الأقل"); return; }
    if (!coords) { setError("الرجاء تحديد موقعك الجغرافي أولاً"); return; }
    createOrderMutation.mutate(
      { data: { userId, waterVolume: selectedVolumes.join(", "), barrelCount, totalPrice, latitude: coords.lat, longitude: coords.lng } },
      {
        onSuccess: () => { queryClient.invalidateQueries({ queryKey: getGetUserOrdersQueryKey(userId) }); onSuccess(); },
        onError: (err: unknown) => {
          const e = err as { response?: { data?: { error?: string } } };
          setError(e?.response?.data?.error || "حدث خطأ في تقديم الطلب");
        },
      }
    );
  };

  return (
    <div className="flex flex-col animate-in slide-in-from-bottom-4 duration-300">
      <div className="flex items-center mb-6">
        <button onClick={onBack} className="p-2 mr-[-8px] text-slate-500 hover:text-primary transition-colors">
          <ArrowRight className="w-6 h-6 ml-2" />
        </button>
        <h1 className="text-2xl font-bold text-slate-800 dark:text-white">طلب مياه جديد</h1>
      </div>

      {error && <div className="bg-destructive/10 text-destructive text-sm p-3 rounded-2xl mb-4">{error}</div>}

      <div className="glass-panel rounded-3xl p-6 mb-6">
        <div className="mb-6">
          <button onClick={handleLocate} disabled={gpsState === "loading" || gpsState === "acquired"}
            className={`w-full py-4 rounded-2xl flex items-center justify-center gap-3 font-bold text-base transition-all shadow-md active:scale-[0.98] ${
              gpsState === "acquired"
                ? "bg-emerald-500 text-white shadow-emerald-500/20 cursor-default"
                : "bg-sky-100 dark:bg-sky-900/30 text-sky-700 dark:text-sky-300 border-2 border-sky-300 dark:border-sky-700 hover:bg-sky-200"
            }`} data-testid="button-locate">
            {gpsState === "loading" ? <Loader2 className="w-5 h-5 animate-spin" /> : <MapPin className="w-5 h-5" />}
            {gpsState === "acquired" ? "تم تحديد موقعك بدقة ✔" : gpsState === "loading" ? "جاري تحديد الموقع..." : "تحديد موقع منزلي تلقائياً"}
          </button>
          {coords && <p className="text-xs text-slate-400 text-center mt-2">{coords.lat.toFixed(5)}, {coords.lng.toFixed(5)}</p>}
        </div>

        <h3 className="font-bold text-lg mb-4 flex items-center gap-2"><Droplet className="w-5 h-5 text-primary" />اختر الحجم (اختر حتى 3)</h3>
        <div className="flex flex-wrap gap-2 mb-6">
          {VOLUMES.map(vol => (
            <button key={vol} onClick={() => toggleVolume(vol)}
              className={`px-4 py-2 rounded-xl border-2 transition-all font-medium ${
                selectedVolumes.includes(vol)
                  ? "bg-primary border-primary text-white shadow-md shadow-primary/20"
                  : "bg-white/50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:border-primary/40"
              } ${selectedVolumes.length >= 3 && !selectedVolumes.includes(vol) ? "opacity-50 cursor-not-allowed" : ""}`}
              data-testid={`volume-${vol}`}>{vol}</button>
          ))}
        </div>

        <h3 className="font-bold text-lg mb-4 flex items-center gap-2"><Package className="w-5 h-5 text-primary" />عدد البراميل</h3>
        <div className="flex gap-2 mb-6">
          {BARRELS.map(count => (
            <button key={count} onClick={() => setBarrelCount(count)}
              className={`flex-1 py-3 rounded-xl border-2 transition-all font-bold text-lg ${
                barrelCount === count
                  ? "bg-primary border-primary text-white shadow-md shadow-primary/20"
                  : "bg-white/50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:border-primary/40"
              }`} data-testid={`barrel-${count}`}>{count}</button>
          ))}
        </div>

        <div className="bg-slate-50 dark:bg-slate-800/50 rounded-2xl p-4 flex justify-between items-center mb-6 border border-slate-100 dark:border-slate-800">
          <span className="text-slate-500 font-medium">السعر الإجمالي:</span>
          <span className="text-2xl font-bold text-primary" data-testid="text-total-price">{totalPrice} دج</span>
        </div>

        <button onClick={handleSubmit} disabled={createOrderMutation.isPending || selectedVolumes.length === 0 || !coords}
          className="w-full bg-gradient-to-r from-primary to-cyan-500 hover:from-primary/90 hover:to-cyan-500/90 text-white font-bold py-4 rounded-2xl flex items-center justify-center gap-2 transition-all shadow-lg shadow-primary/30 disabled:opacity-50"
          data-testid="button-submit-order">
          {createOrderMutation.isPending
            ? <Loader2 className="w-6 h-6 animate-spin" />
            : <><CheckCircle2 className="w-5 h-5" /><span>إتمام الطلب</span></>}
        </button>
      </div>
    </div>
  );
}

function MyOrdersView({ onBack, userId, onDriverArrived }: {
  onBack: () => void; userId: string; onDriverArrived: (orderId: string) => void;
}) {
  const { data: orders, isLoading } = useGetUserOrders(userId, {
    query: {
      enabled: !!userId,
      queryKey: getGetUserOrdersQueryKey(userId),
      refetchInterval: 5000,
    },
  });

  const notifiedRef = useRef<Set<string>>(new Set());

  const checkArrival = useCallback(() => {
    if (!orders) return;
    for (const order of orders) {
      if (order.status === "وصل السائق" && !notifiedRef.current.has(order.id)) {
        notifiedRef.current.add(order.id);
        onDriverArrived(order.id);
      }
    }
  }, [orders, onDriverArrived]);

  useEffect(() => { checkArrival(); }, [checkArrival]);

  return (
    <div className="flex flex-col animate-in slide-in-from-bottom-4 duration-300 h-full">
      <div className="flex items-center mb-6">
        <button onClick={onBack} className="p-2 mr-[-8px] text-slate-500 hover:text-primary transition-colors">
          <ArrowRight className="w-6 h-6 ml-2" />
        </button>
        <h1 className="text-2xl font-bold text-slate-800 dark:text-white">طلباتي</h1>
        <span className="mr-2 text-xs text-slate-400">(يتحدث تلقائياً)</span>
      </div>

      {isLoading ? (
        <div className="flex flex-col items-center justify-center py-20 text-primary">
          <Loader2 className="w-10 h-10 animate-spin mb-4" /><p>جاري تحميل الطلبات...</p>
        </div>
      ) : !orders || orders.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-slate-400 glass-panel rounded-3xl">
          <Package className="w-16 h-16 mb-4 opacity-50" /><p className="text-lg">لا توجد طلبات سابقة</p>
        </div>
      ) : (
        <div className="space-y-4 pb-10">
          {orders.map(order => (
            <div key={order.id}
              className={`glass-panel p-5 rounded-3xl border-2 transition-all ${
                order.status === "وصل السائق"
                  ? "border-amber-400 shadow-amber-200 dark:shadow-amber-900/30 shadow-lg"
                  : "border-transparent"
              }`} data-testid={`order-card-${order.id}`}>
              <div className="flex justify-between items-start mb-3 border-b border-slate-100 dark:border-slate-800 pb-3">
                <div className="flex flex-col">
                  <span className="font-bold text-lg text-slate-800 dark:text-white">
                    {order.waterVolume}{" "}
                    <span className="text-sm font-normal text-slate-500 px-1">({order.barrelCount} براميل)</span>
                  </span>
                  <span className="text-xs text-slate-400">{format(new Date(order.createdAt), "dd/MM/yyyy HH:mm")}</span>
                </div>
                <div className="text-lg font-bold text-primary">{order.totalPrice} دج</div>
              </div>
              <div className="flex items-center gap-2 mt-2">
                {order.status === "معلق" && (
                  <div className="flex items-center gap-1.5 text-slate-500 bg-slate-100 dark:bg-slate-800 px-3 py-1.5 rounded-full text-sm font-medium">
                    <Clock className="w-4 h-4" /><span>معلق — بانتظار السائق</span>
                  </div>
                )}
                {order.status === "قيد التحضير" && (
                  <div className="flex items-center gap-1.5 text-slate-500 bg-slate-100 dark:bg-slate-800 px-3 py-1.5 rounded-full text-sm font-medium">
                    <Clock className="w-4 h-4" /><span>قيد التحضير</span>
                  </div>
                )}
                {order.status === "قيد التوصيل" && (
                  <div className="flex items-center gap-1.5 text-amber-600 bg-amber-50 dark:bg-amber-900/20 px-3 py-1.5 rounded-full text-sm font-medium animate-pulse">
                    <Truck className="w-4 h-4" /><span>قيد التوصيل</span>
                  </div>
                )}
                {order.status === "وصل السائق" && (
                  <div className="flex items-center gap-1.5 text-orange-600 bg-orange-50 dark:bg-orange-900/20 px-3 py-1.5 rounded-full text-sm font-bold">
                    <Bell className="w-4 h-4 animate-bounce" /><span>وصل السائق!</span>
                  </div>
                )}
                {order.status === "تم التوصيل" && (
                  <div className="flex items-center gap-1.5 text-emerald-600 bg-emerald-50 dark:bg-emerald-900/20 px-3 py-1.5 rounded-full text-sm font-medium">
                    <CheckCircle2 className="w-4 h-4" /><span>تم التوصيل ✔</span>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
