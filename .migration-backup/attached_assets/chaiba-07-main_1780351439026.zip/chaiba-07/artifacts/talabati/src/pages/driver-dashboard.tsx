import { useState, useRef, useEffect, useCallback } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Layout } from "@/components/layout";
import {
  useGetActiveOrders,
  getGetActiveOrdersQueryKey,
  useGetOrdersSummary,
  getGetOrdersSummaryQueryKey,
  useUpdateOrderStatus,
  useGetDriverStatus,
  getGetDriverStatusQueryKey,
  useUpdateDriverStatus,
  useAcceptOrder,
  useGetDriverOrders,
  getGetDriverOrdersQueryKey,
  useGetDriverAccount,
  getGetDriverAccountQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useRealtimeOrders } from "@/hooks/use-realtime-orders";
import { OrderNotification } from "@/components/order-notification";
import {
  Package, Truck, CheckCircle2, User, Phone, MapPin,
  Loader2, PlayCircle, PauseCircle, XCircle, Bell, Coffee, Timer,
  CreditCard, Clock, ShieldAlert
} from "lucide-react";
import { format } from "date-fns";
import type { DriverStatusInputCurrentStatus } from "@workspace/api-client-react";
import { updateDriverLocation } from "@/lib/supabase";

// ─────────────────────────────────────────────────────────────────────────────
// Root page
// ─────────────────────────────────────────────────────────────────────────────
export default function DriverDashboard() {
  const { userId, userType } = useAuth();
  const [, setLocation] = useLocation();

  if (!userId) { setLocation("/"); return null; }
  if (userType !== "سائق") { setLocation("/dashboard"); return null; }

  return (
    <Layout>
      <DriverDashboardContent driverId={userId} />
    </Layout>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Blocking overlay — Pending account (awaiting admin approval)
// ─────────────────────────────────────────────────────────────────────────────
function PendingAccountOverlay() {
  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center bg-black/70 backdrop-blur-sm">
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-8 mx-4 max-w-sm w-full shadow-2xl border border-amber-200 dark:border-amber-700 text-center animate-in zoom-in-95 duration-300" dir="rtl">
        <div className="w-20 h-20 bg-amber-100 dark:bg-amber-900/30 rounded-full flex items-center justify-center mx-auto mb-5">
          <ShieldAlert className="w-10 h-10 text-amber-500" />
        </div>
        <h2 className="text-xl font-black text-slate-800 dark:text-white mb-4">حسابك قيد المراجعة</h2>
        <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-700 rounded-2xl p-4 text-right">
          <p className="text-slate-700 dark:text-slate-200 text-sm leading-loose font-bold">
            ملاحظة: الوثائق والصور المطلوبة هي مجرد إجراء شكلي وأمني للتحقق من هوية السائق، والتأكد من جِدية الحساب ومنع السائقين الوهميين. حسابك حالياً قيد المراجعة والتدقيق من قِبل إدارة المشروع.
          </p>
        </div>
        <div className="flex items-center justify-center gap-2 mt-5 text-amber-600 dark:text-amber-400">
          <Clock className="w-4 h-4 animate-pulse" />
          <span className="text-sm font-medium">يتم التحقق تلقائياً عند القبول</span>
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Blocking overlay — Subscription expired
// ─────────────────────────────────────────────────────────────────────────────
function ExpiredSubscriptionOverlay() {
  const [, setLocation] = useLocation();
  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center bg-black/70 backdrop-blur-sm">
      <div className="bg-white dark:bg-slate-900 rounded-3xl p-8 mx-4 max-w-sm w-full shadow-2xl border border-red-200 dark:border-red-700 text-center animate-in zoom-in-95 duration-300" dir="rtl">
        <div className="w-20 h-20 bg-red-100 dark:bg-red-900/30 rounded-full flex items-center justify-center mx-auto mb-5">
          <CreditCard className="w-10 h-10 text-red-500" />
        </div>
        <h2 className="text-xl font-black text-slate-800 dark:text-white mb-4">انتهى اشتراكك الشهري</h2>
        <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-700 rounded-2xl p-4 text-right">
          <p className="text-slate-700 dark:text-slate-200 text-sm leading-loose font-bold">
            انتهت أيام اشتراكك الشهري (500 دج). يرجى تجديد الاشتراك للاستمرار في استقبال طلبات المياه.
          </p>
        </div>
        <button
          onClick={() => setLocation("/subscription")}
          className="mt-6 w-full py-4 rounded-2xl flex items-center justify-center gap-3 font-bold text-white bg-gradient-to-r from-primary to-cyan-500 shadow-lg shadow-primary/30 hover:opacity-90 transition-all active:scale-[0.98]"
        >
          <CreditCard className="w-5 h-5" />التوجه إلى صفحة الاشتراك
        </button>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Main content
// ─────────────────────────────────────────────────────────────────────────────
function DriverDashboardContent({ driverId }: { driverId: string }) {
  const queryClient = useQueryClient();

  const { data: statuses } = useGetDriverStatus({
    query: { queryKey: getGetDriverStatusQueryKey(), refetchInterval: 15000 }
  });

  const { data: account } = useGetDriverAccount(driverId, {
    query: { queryKey: getGetDriverAccountQueryKey(driverId), refetchInterval: 10000 }
  });

  const myStatusObj = statuses?.find(s => s.driverId === driverId);
  const currentStatus = (myStatusObj?.currentStatus || "مغلق") as DriverStatusInputCurrentStatus;

  const handleStatusChange = useCallback(
    (status: DriverStatusInputCurrentStatus, mutate: (args: { data: { driverId: string; currentStatus: DriverStatusInputCurrentStatus } }, opts: object) => void) => {
      mutate(
        { data: { driverId, currentStatus: status } },
        { onSuccess: () => queryClient.invalidateQueries({ queryKey: getGetDriverStatusQueryKey() }) }
      );
    },
    [driverId, queryClient]
  );

  const isPending = account?.accountStatus === "pending";
  const isExpired = account?.subscriptionExpired === true;

  return (
    <>
      {isPending && <PendingAccountOverlay />}
      {!isPending && isExpired && <ExpiredSubscriptionOverlay />}

      <div className="flex flex-col gap-6 w-full animate-in fade-in duration-500">
        <SummaryStats />
        <AttendanceControl driverId={driverId} currentStatus={currentStatus} onStatusChange={handleStatusChange} />

        {currentStatus === "حاضر" && (
          <>
            <MyActiveDeliveries driverId={driverId} />
            <PendingOrdersQueue driverId={driverId} />
          </>
        )}

        {currentStatus === "استراحة" && (
          <BreakView driverId={driverId} onEndBreak={handleStatusChange} />
        )}

        {currentStatus === "مغلق" && <ClosedView />}
      </div>
    </>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Summary stats bar
// ─────────────────────────────────────────────────────────────────────────────
function SummaryStats() {
  const { data: summary } = useGetOrdersSummary({
    query: { queryKey: getGetOrdersSummaryQueryKey(), refetchInterval: 15000 }
  });
  if (!summary) return null;
  return (
    <div className="grid grid-cols-3 gap-3">
      <div className="glass-panel p-3 flex flex-col items-center rounded-2xl">
        <span className="text-xs text-slate-500 font-medium">الإجمالي</span>
        <span className="text-xl font-bold text-slate-800 dark:text-white">{summary.total}</span>
      </div>
      <div className="glass-panel p-3 flex flex-col items-center rounded-2xl bg-amber-50/50 dark:bg-amber-900/10">
        <span className="text-xs text-amber-600 font-medium">قيد التوصيل</span>
        <span className="text-xl font-bold text-amber-700">{summary.inDelivery}</span>
      </div>
      <div className="glass-panel p-3 flex flex-col items-center rounded-2xl bg-emerald-50/50 dark:bg-emerald-900/10">
        <span className="text-xs text-emerald-600 font-medium">مكتمل</span>
        <span className="text-xl font-bold text-emerald-700">{summary.delivered}</span>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Attendance pill slider
// ─────────────────────────────────────────────────────────────────────────────
function AttendanceControl({
  driverId, currentStatus, onStatusChange,
}: {
  driverId: string;
  currentStatus: DriverStatusInputCurrentStatus;
  onStatusChange: (
    status: DriverStatusInputCurrentStatus,
    mutate: (args: { data: { driverId: string; currentStatus: DriverStatusInputCurrentStatus } }, opts: object) => void
  ) => void;
}) {
  const updateStatusMutation = useUpdateDriverStatus();

  const getStatusOffset = () => {
    switch (currentStatus) {
      case "حاضر":    return "translate-x-0";
      case "استراحة": return "-translate-x-full";
      case "مغلق":    return "-translate-x-[200%]";
      default:         return "-translate-x-[200%]";
    }
  };

  const getStatusColor = () => {
    switch (currentStatus) {
      case "حاضر":    return "bg-emerald-500 shadow-emerald-500/40";
      case "استراحة": return "bg-amber-500 shadow-amber-500/40";
      case "مغلق":    return "bg-destructive shadow-destructive/40";
      default:         return "bg-destructive";
    }
  };

  const change = (s: DriverStatusInputCurrentStatus) => {
    if (s === currentStatus) return;
    onStatusChange(s, updateStatusMutation.mutate);
  };

  return (
    <div className="glass-panel p-5 rounded-3xl">
      <h3 className="font-bold text-slate-800 dark:text-white mb-4 text-center">حالة التواجد</h3>
      <div className="relative bg-slate-100 dark:bg-slate-800/80 p-1.5 rounded-full flex h-14" dir="rtl">
        <div className={`absolute top-1.5 bottom-1.5 w-[calc(33.333%-4px)] rounded-full transition-all duration-300 shadow-lg ${getStatusColor()} ${getStatusOffset()}`} />
        <button onClick={() => change("حاضر")}
          className={`flex-1 relative z-10 flex items-center justify-center gap-1.5 font-bold text-sm transition-colors duration-300 ${currentStatus === "حاضر" ? "text-white" : "text-slate-500"}`}
          data-testid="status-active"><PlayCircle className="w-4 h-4" /> حاضر</button>
        <button onClick={() => change("استراحة")}
          className={`flex-1 relative z-10 flex items-center justify-center gap-1.5 font-bold text-sm transition-colors duration-300 ${currentStatus === "استراحة" ? "text-white" : "text-slate-500"}`}
          data-testid="status-break"><PauseCircle className="w-4 h-4" /> استراحة</button>
        <button onClick={() => change("مغلق")}
          className={`flex-1 relative z-10 flex items-center justify-center gap-1.5 font-bold text-sm transition-colors duration-300 ${currentStatus === "مغلق" ? "text-white" : "text-slate-500"}`}
          data-testid="status-closed"><XCircle className="w-4 h-4" /> مغلق</button>
      </div>
      {updateStatusMutation.isPending && (
        <div className="text-center mt-2"><Loader2 className="w-4 h-4 animate-spin text-primary inline-block" /></div>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Break view
// ─────────────────────────────────────────────────────────────────────────────
const BREAK_SECONDS = 30 * 60;

function BreakView({
  driverId, onEndBreak,
}: {
  driverId: string;
  onEndBreak: (
    status: DriverStatusInputCurrentStatus,
    mutate: (args: { data: { driverId: string; currentStatus: DriverStatusInputCurrentStatus } }, opts: object) => void
  ) => void;
}) {
  const [secondsLeft, setSecondsLeft] = useState(BREAK_SECONDS);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const updateStatusMutation = useUpdateDriverStatus();

  useEffect(() => {
    setSecondsLeft(BREAK_SECONDS);
    intervalRef.current = setInterval(() => {
      setSecondsLeft(prev => {
        if (prev <= 1) { clearInterval(intervalRef.current!); return 0; }
        return prev - 1;
      });
    }, 1000);
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, []);

  const minutes = String(Math.floor(secondsLeft / 60)).padStart(2, "0");
  const seconds = String(secondsLeft % 60).padStart(2, "0");
  const progress = ((BREAK_SECONDS - secondsLeft) / BREAK_SECONDS) * 100;
  const isExpired = secondsLeft === 0;

  const handleEndBreak = () => {
    if (intervalRef.current) clearInterval(intervalRef.current);
    onEndBreak("حاضر", updateStatusMutation.mutate);
  };

  return (
    <div className="glass-panel rounded-3xl p-8 flex flex-col items-center gap-6 animate-in fade-in duration-400">
      <div className={`w-20 h-20 rounded-full flex items-center justify-center shadow-lg ${isExpired ? "bg-emerald-100 dark:bg-emerald-900/30" : "bg-amber-100 dark:bg-amber-900/30"}`}>
        {isExpired ? <Coffee className="w-10 h-10 text-emerald-500" /> : <Timer className="w-10 h-10 text-amber-500" />}
      </div>
      <div className="relative flex items-center justify-center w-40 h-40">
        <svg className="absolute inset-0 w-full h-full -rotate-90" viewBox="0 0 160 160">
          <circle cx="80" cy="80" r="70" fill="none" stroke="currentColor" strokeWidth="8" className="text-slate-200 dark:text-slate-700" />
          <circle cx="80" cy="80" r="70" fill="none" stroke="currentColor" strokeWidth="8"
            strokeDasharray={`${2 * Math.PI * 70}`}
            strokeDashoffset={`${2 * Math.PI * 70 * (1 - progress / 100)}`}
            strokeLinecap="round"
            className={`transition-all duration-1000 ${isExpired ? "text-emerald-500" : "text-amber-500"}`} />
        </svg>
        <div className="text-center z-10">
          <div className={`text-4xl font-black tabular-nums tracking-tight ${isExpired ? "text-emerald-600" : "text-amber-600"}`}>
            {minutes}:{seconds}
          </div>
          <div className="text-xs text-slate-400 font-medium mt-1">{isExpired ? "انتهت الاستراحة" : "استراحة"}</div>
        </div>
      </div>
      <p className="text-slate-600 dark:text-slate-300 text-center text-sm leading-relaxed max-w-xs">
        {isExpired ? "انتهت مدة استراحتك. أنت جاهز للعودة واستقبال الطلبات." : "أنت في وضع الاستراحة. لن تظهر لك طلبات جديدة خلال هذه الفترة."}
      </p>
      <button onClick={handleEndBreak} disabled={updateStatusMutation.isPending}
        className={`w-full py-4 rounded-2xl flex items-center justify-center gap-3 font-bold text-white shadow-lg transition-all active:scale-[0.98] ${
          isExpired ? "bg-gradient-to-r from-emerald-500 to-teal-500 shadow-emerald-400/30 animate-pulse" : "bg-gradient-to-r from-amber-500 to-orange-500 shadow-amber-400/30"
        }`} data-testid="button-end-break">
        {updateStatusMutation.isPending ? <Loader2 className="w-5 h-5 animate-spin" /> : <PlayCircle className="w-5 h-5" />}
        إنهاء الاستراحة والعودة للعمل
      </button>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Closed view
// ─────────────────────────────────────────────────────────────────────────────
function ClosedView() {
  return (
    <div className="glass-panel rounded-3xl p-10 flex flex-col items-center gap-5 text-center animate-in fade-in duration-400">
      <div className="w-20 h-20 bg-red-50 dark:bg-red-900/20 rounded-full flex items-center justify-center shadow-inner">
        <XCircle className="w-10 h-10 text-destructive" />
      </div>
      <h3 className="text-xl font-black text-slate-800 dark:text-white">الحساب مغلق</h3>
      <p className="text-slate-500 dark:text-slate-400 leading-relaxed max-w-xs">
        حسابك مغلق حالياً. يرجى تفعيل وضع الحضور لاستقبال طلبات المياه 💧
      </p>
      <div className="flex gap-2 mt-2">
        {[..."💧💧💧"].map((d, i) => (
          <span key={i} className="text-2xl animate-bounce" style={{ animationDelay: `${i * 0.15}s` }}>{d}</span>
        ))}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// My in-progress deliveries
// ─────────────────────────────────────────────────────────────────────────────
function MyActiveDeliveries({ driverId }: { driverId: string }) {
  const queryClient = useQueryClient();
  const { data: orders, isLoading } = useGetDriverOrders(driverId, {
    query: { queryKey: getGetDriverOrdersQueryKey(driverId), refetchInterval: 8000 }
  });
  const updateStatusMutation = useUpdateOrderStatus();

  if (isLoading || !orders || orders.length === 0) return null;

  return (
    <div className="space-y-4">
      <h2 className="font-bold text-lg text-primary px-2 flex items-center gap-2">
        <Truck className="w-5 h-5" />توصيلاتي النشطة
      </h2>
      {orders.map(order => (
        <div key={order.id} className="glass-panel p-5 rounded-3xl border-2 border-primary/30 relative overflow-hidden" data-testid={`my-delivery-${order.id}`}>
          <div className="absolute top-0 right-0 w-1.5 h-full bg-primary" />

          <div className="flex justify-between items-start mb-3 pb-3 border-b border-slate-100 dark:border-slate-800">
            <div>
              <span className="font-bold text-lg text-primary">{order.waterVolume}</span>
              <div className="text-sm text-slate-500">{order.barrelCount} براميل</div>
            </div>
            <div className="text-xl font-black text-slate-800 dark:text-white">
              {order.totalPrice} <span className="text-sm font-normal">دج</span>
            </div>
          </div>

          <div className="space-y-2 mb-4 text-sm text-slate-600 dark:text-slate-300">
            <div className="flex items-center gap-2"><User className="w-4 h-4 text-slate-400" /><span>{order.userName || "عميل"}</span></div>
            {order.userPhone && (
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-slate-400" />
                <a href={`tel:${order.userPhone}`} className="text-primary font-bold hover:underline">{order.userPhone}</a>
              </div>
            )}
            {order.latitude && order.longitude && (
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-slate-400" />
                <span className="text-xs text-slate-400">{Number(order.latitude).toFixed(5)}, {Number(order.longitude).toFixed(5)}</span>
              </div>
            )}
          </div>

          {/* [تعديل 3]: خريطة الأقمار الصناعية الحية مع تحديث مستمر لموقع السائق */}
          {order.latitude && order.longitude && (
            <SatelliteMap
              orderId={order.id}
              driverId={driverId}
              destLat={Number(order.latitude)}
              destLng={Number(order.longitude)}
            />
          )}

          <div className="space-y-3 mt-4">
            {order.status === "قيد التوصيل" && (
              <button
                onClick={() => updateStatusMutation.mutate(
                  { orderId: order.id, data: { status: "وصل السائق" } },
                  {
                    onSuccess: () => {
                      queryClient.invalidateQueries({ queryKey: getGetDriverOrdersQueryKey(driverId) });
                      queryClient.invalidateQueries({ queryKey: getGetOrdersSummaryQueryKey() });
                    }
                  }
                )}
                disabled={updateStatusMutation.isPending}
                className="w-full py-3.5 rounded-2xl flex items-center justify-center gap-2 font-bold bg-amber-400 hover:bg-amber-500 text-white shadow-md shadow-amber-400/30 animate-pulse transition-all active:scale-[0.98]"
                data-testid={`button-arrived-${order.id}`}
              >
                <Bell className="w-5 h-5" />لقد وصلت إلى منزل العميل
              </button>
            )}
            {(order.status === "وصل السائق" || order.status === "قيد التوصيل") && (
              <button
                onClick={() => updateStatusMutation.mutate(
                  { orderId: order.id, data: { status: "تم التوصيل" } },
                  {
                    onSuccess: () => {
                      queryClient.invalidateQueries({ queryKey: getGetDriverOrdersQueryKey(driverId) });
                      queryClient.invalidateQueries({ queryKey: getGetActiveOrdersQueryKey() });
                      queryClient.invalidateQueries({ queryKey: getGetOrdersSummaryQueryKey() });
                    }
                  }
                )}
                disabled={updateStatusMutation.isPending}
                className="w-full py-3.5 rounded-2xl flex items-center justify-center gap-2 font-bold bg-emerald-500 hover:bg-emerald-600 text-white shadow-md shadow-emerald-500/20 transition-all active:scale-[0.98]"
                data-testid={`button-complete-${order.id}`}
              >
                <CheckCircle2 className="w-5 h-5" />تأكيد التسليم
              </button>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// [تعديل 3]: خريطة الأقمار الصناعية الحية — Live Satellite GPS Map
//
// • تعرض صور الأقمار الصناعية (Esri World Imagery — مجانية بدون API Key)
// • تستخدم navigator.geolocation.watchPosition للتحديث الحي المستمر
// • مؤشر السائق يتحرك تلقائياً مع تغيّر موقعه الفعلي
// • ترسل الإحداثيات إلى Supabase كل 5 ثوانٍ
// ─────────────────────────────────────────────────────────────────────────────
function SatelliteMap({
  orderId, driverId, destLat, destLng,
}: {
  orderId: string;
  driverId: string;
  destLat: number;
  destLng: number;
}) {
  const mapRef         = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<unknown>(null);
  const driverMarkerRef = useRef<unknown>(null);
  const watchIdRef     = useRef<number | null>(null);
  const lastSupabaseUpdate = useRef<number>(0);

  useEffect(() => {
    if (!mapRef.current || mapInstanceRef.current) return;

    // Load Leaflet CSS once
    if (!document.querySelector('link[href*="leaflet"]')) {
      const link = document.createElement("link");
      link.rel  = "stylesheet";
      link.href = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.css";
      document.head.appendChild(link);
    }

    const win = window as unknown as Record<string, unknown>;

    const initMap = () => {
      if (!mapRef.current || mapInstanceRef.current) return;

      type LeafletType = {
        map: (el: HTMLElement, opts: object) => {
          setView: (c: [number, number], z: number) => void;
          fitBounds: (b: [[number, number], [number, number]], opts: object) => void;
          remove: () => void;
        };
        tileLayer: (url: string, opts: object) => { addTo: (m: unknown) => unknown };
        marker: (c: [number, number], opts?: object) => {
          addTo: (m: unknown) => { bindPopup: (s: string) => unknown };
          setLatLng: (c: [number, number]) => void;
          bindPopup: (s: string) => unknown;
        };
        divIcon: (opts: object) => object;
        latLngBounds: (corners: [[number, number], [number, number]]) => unknown;
      };

      const L = win["L"] as LeafletType;

      // Initialize map
      const map = L.map(mapRef.current!, {
        zoomControl: true,
        attributionControl: false,
      });
      mapInstanceRef.current = map;

      // Center on destination initially
      map.setView([destLat, destLng], 15);

      // ── Satellite tile layer (Esri World Imagery — مجانية بدون API Key) ──
      L.tileLayer(
        "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
        {
          maxZoom: 19,
          attribution: "© Esri, Maxar, Earthstar Geographics",
        }
      ).addTo(map);

      // Destination marker (red pin)
      const destIcon = L.divIcon({
        html: `<div style="
          width:18px;height:18px;border-radius:50%;
          background:#ef4444;border:3px solid white;
          box-shadow:0 2px 10px rgba(0,0,0,0.5)"></div>`,
        className: "",
        iconSize: [18, 18],
        iconAnchor: [9, 9],
      });
      L.marker([destLat, destLng], { icon: destIcon })
        .addTo(map)
        .bindPopup("📍 موقع العميل");

      // Driver icon (blue pulsing dot)
      const driverIcon = L.divIcon({
        html: `<div style="position:relative;width:24px;height:24px">
          <div style="
            position:absolute;inset:0;border-radius:50%;
            background:#0ea5e9;opacity:0.3;
            animation:ping 1.2s cubic-bezier(0,0,0.2,1) infinite"></div>
          <div style="
            position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);
            width:14px;height:14px;border-radius:50%;
            background:#0ea5e9;border:2px solid white;
            box-shadow:0 2px 8px rgba(14,165,233,0.7)"></div>
        </div>`,
        className: "",
        iconSize: [24, 24],
        iconAnchor: [12, 12],
      });

      // Inject ping animation keyframes once
      if (!document.getElementById("driver-ping-style")) {
        const style = document.createElement("style");
        style.id = "driver-ping-style";
        style.textContent = `@keyframes ping{75%,100%{transform:scale(2.5);opacity:0}}`;
        document.head.appendChild(style);
      }

      // ── watchPosition — تحديث حي ومستمر لموقع السائق ──
      watchIdRef.current = navigator.geolocation.watchPosition(
        (pos) => {
          const { latitude, longitude } = pos.coords;
          const latLng: [number, number] = [latitude, longitude];

          if (!driverMarkerRef.current) {
            // أول موقع — إنشاء المؤشر وضبط حدود الخريطة
            driverMarkerRef.current = L.marker(latLng, { icon: driverIcon })
              .addTo(map)
              .bindPopup("🚚 موقعي الحالي");

            map.fitBounds(
              [[latitude, longitude], [destLat, destLng]],
              { padding: [50, 50] }
            );
          } else {
            // تحديث موقع المؤشر بدون إعادة تحميل الصفحة
            (driverMarkerRef.current as { setLatLng: (c: [number, number]) => void })
              .setLatLng(latLng);
          }

          // إرسال الإحداثيات إلى Supabase كل 5 ثوانٍ فقط
          const now = Date.now();
          if (now - lastSupabaseUpdate.current > 5000) {
            lastSupabaseUpdate.current = now;
            updateDriverLocation(driverId, latitude, longitude);
          }
        },
        (err) => {
          // GPS unavailable — show destination only, no crash
          console.warn("[GPS] watchPosition error:", err.message);
        },
        {
          enableHighAccuracy: true,
          timeout: 15000,
          maximumAge: 2000,   // قبول موقع لا يزيد عمره عن 2 ثانية
        }
      );
    };

    const loadLeaflet = async () => {
      if (!win["L"]) {
        await new Promise<void>(resolve => {
          const s = document.createElement("script");
          s.src = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.js";
          s.onload = () => resolve();
          document.head.appendChild(s);
        });
      }
      initMap();
    };

    loadLeaflet();

    return () => {
      // تنظيف: إيقاف المراقبة وإزالة الخريطة
      if (watchIdRef.current !== null) {
        navigator.geolocation.clearWatch(watchIdRef.current);
        watchIdRef.current = null;
      }
      if (mapInstanceRef.current) {
        (mapInstanceRef.current as { remove: () => void }).remove();
        mapInstanceRef.current = null;
      }
      driverMarkerRef.current = null;
    };
  }, [orderId, destLat, destLng, driverId]);

  return (
    <div
      ref={mapRef}
      className="w-full rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-700"
      style={{ height: "240px" }}
      data-testid={`map-${orderId}`}
    />
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Queue of pending orders
// ─────────────────────────────────────────────────────────────────────────────
function PendingOrdersQueue({ driverId }: { driverId: string }) {
  const queryClient = useQueryClient();
  const { data: orders, isLoading } = useGetActiveOrders(
    { driverId },
    { query: { queryKey: getGetActiveOrdersQueryKey({ driverId }), refetchInterval: 6000 } }
  );
  const acceptMutation = useAcceptOrder();

  // Realtime push notifications — fires only when a new order appears in this driver's commune
  const { notification, dismiss } = useRealtimeOrders(driverId, orders?.length ?? 0);

  const handleAccept = (orderId: string) => {
    acceptMutation.mutate(
      { orderId, data: { driverId } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetActiveOrdersQueryKey() });
          queryClient.invalidateQueries({ queryKey: getGetDriverOrdersQueryKey(driverId) });
          queryClient.invalidateQueries({ queryKey: getGetOrdersSummaryQueryKey() });
        },
        onError: () => {
          queryClient.invalidateQueries({ queryKey: getGetActiveOrdersQueryKey() });
        }
      }
    );
  };

  if (isLoading) {
    return <div className="flex justify-center p-10"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>;
  }

  return (
    <>
      <OrderNotification show={notification} onDismiss={dismiss} />

    <div className="space-y-4">
      <h2 className="font-bold text-lg text-slate-800 dark:text-white px-2 flex items-center gap-2">
        <Package className="w-5 h-5" />الطلبات المتاحة
        {orders && orders.length > 0 && (
          <span className="bg-primary text-white text-xs rounded-full px-2 py-0.5">{orders.length}</span>
        )}
      </h2>

      {!orders || orders.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 text-slate-400 glass-panel rounded-3xl">
          <Package className="w-14 h-14 mb-4 opacity-40" />
          <p className="text-base">لا توجد طلبات معلقة حالياً</p>
        </div>
      ) : (
        orders.map(order => (
          <div key={order.id} className="glass-panel p-5 rounded-3xl overflow-hidden relative" data-testid={`pending-order-${order.id}`}>
            <div className="absolute top-0 right-0 w-1 h-full bg-sky-400" />

            <div className="flex justify-between items-start mb-4 border-b border-slate-100 dark:border-slate-800 pb-4">
              <div>
                <span className="font-bold text-lg text-primary">{order.waterVolume}</span>
                <div className="text-sm text-slate-500">{order.barrelCount} براميل</div>
              </div>
              <div className="text-right">
                <div className="text-xl font-black text-slate-800 dark:text-white">
                  {order.totalPrice} <span className="text-sm font-normal">دج</span>
                </div>
                <div className="text-xs text-slate-400">{format(new Date(order.createdAt), "HH:mm")}</div>
              </div>
            </div>

            <div className="space-y-2 mb-5 text-sm text-slate-600 dark:text-slate-300">
              <div className="flex items-center gap-2"><User className="w-4 h-4 text-slate-400" /><span>{order.userName || "عميل"}</span></div>
              {order.userPhone && (
                <div className="flex items-center gap-2">
                  <Phone className="w-4 h-4 text-slate-400" />
                  <a href={`tel:${order.userPhone}`} className="text-primary font-bold hover:underline">{order.userPhone}</a>
                </div>
              )}
              {order.latitude && order.longitude && (
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-emerald-500" />
                  <span className="text-emerald-600 dark:text-emerald-400 text-xs">تم تحديد موقع العميل بدقة</span>
                </div>
              )}
            </div>

            <button
              onClick={() => handleAccept(order.id)}
              disabled={acceptMutation.isPending}
              className="w-full py-3.5 rounded-2xl flex items-center justify-center gap-2 font-bold bg-gradient-to-r from-primary to-cyan-500 text-white shadow-lg shadow-primary/25 hover:opacity-90 transition-all active:scale-[0.98] disabled:opacity-50"
              data-testid={`button-accept-${order.id}`}
            >
              {acceptMutation.isPending
                ? <Loader2 className="w-5 h-5 animate-spin" />
                : <><Truck className="w-5 h-5" /> قبول وتوصيل الطلب</>}
            </button>
          </div>
        ))
      )}
    </div>
    </>
  );
}
