import { pgTable, text, integer, numeric, timestamp } from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";

export const usersTable = pgTable("users", {
  id: text("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  phone: text("phone").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  userType: text("user_type").notNull(),
  wilaya: text("wilaya").notNull().default(""),
  commune: text("commune").notNull().default(""),
  accountStatus: text("account_status").notNull().default("pending"),
  subscriptionExpiresAt: timestamp("subscription_expires_at"),
});

export const driverStatusTable = pgTable("driver_status", {
  driverId: text("driver_id").primaryKey(),
  currentStatus: text("current_status").notNull().default("مغلق"),
  updatedAt: timestamp("updated_at").notNull().default(sql`now()`),
});

export const driverDetailsTable = pgTable("driver_details", {
  driverId: text("driver_id").primaryKey(),
  wilaya: text("wilaya").notNull().default(""),
  commune: text("commune").notNull().default(""),
  truckFrontPhotoUrl: text("truck_front_photo_url"),
  driverLicenseUrl: text("driver_license_url"),
  truckVideoUrl: text("truck_video_url"),
  truckSidePhotoUrl: text("truck_side_photo_url"),
});

export const ordersTable = pgTable("orders", {
  id: text("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: text("user_id").notNull(),
  driverId: text("driver_id"),
  waterVolume: text("water_volume").notNull(),
  barrelCount: integer("barrel_count").notNull().default(0),
  totalPrice: numeric("total_price").notNull(),
  latitude: text("latitude"),
  longitude: text("longitude"),
  status: text("status").notNull().default("معلق"),
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
});

export const subscriptionPaymentsTable = pgTable("subscription_payments", {
  id: text("id").primaryKey().default(sql`gen_random_uuid()`),
  driverId: text("driver_id").notNull(),
  receiptImage: text("receipt_image").notNull(),
  status: text("status").notNull().default("pending"),
  adminNotes: text("admin_notes"),
  createdAt: timestamp("created_at").notNull().default(sql`now()`),
  reviewedAt: timestamp("reviewed_at"),
});
