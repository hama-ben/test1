import express, { type Express } from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import router from "./routes";
import { logger } from "./lib/logger";
import { authRateLimiter } from "./middlewares/auth-rate-limit";

const app: Express = express();

// Trust exactly one proxy hop (Render's load balancer, Replit's proxy, etc.)
// Without this, express-rate-limit throws ERR_ERL_UNEXPECTED_X_FORWARDED_FOR
// when it sees the X-Forwarded-For header set by the reverse proxy in front of us.
app.set("trust proxy", 1);

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
// CORS — allow all origins.
// The API is consumed by:
//   - The Replit web preview (dynamic *.replit.dev origin)
//   - The Android WebView (origin: capacitor://localhost or https://localhost)
//   - Future web/mobile clients
// All authentication is header-based (X-Session-Token, X-User-Id), not
// cookie-based, so an open CORS policy carries no additional risk.
app.use(cors({ origin: true, credentials: true }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Auth rate limiter — scoped to /api/auth/* only.
// /api/health and /api/healthz are on a different path and are never affected.
app.use("/api/auth", authRateLimiter);

app.use("/api", router);

export default app;
